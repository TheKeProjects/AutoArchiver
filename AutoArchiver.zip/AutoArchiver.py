import sys
import os
import re
import shutil
import ctypes
import urllib.request
import tempfile
import subprocess
import webbrowser
import threading
from pathlib import Path
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QListWidget, QComboBox, QMessageBox, QLineEdit, QProgressBar,
    QFrame, QSizePolicy
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import QPalette, QColor, QFont, QIcon, QPixmap, QLinearGradient, QPainter
from PyQt6.QtSvgWidgets import QSvgWidget
from PIL import Image

# ===== CONSTANTES Y CONFIGURACIÓN DE ACTUALIZACIONES =====
CONFIG_DIR = os.path.join(os.path.expanduser('~'), 'Documents', 'AutoArchiver')
VERSION_FILE = os.path.join(CONFIG_DIR, 'file_organizer_version.txt')
CHANGELOG_FILE = os.path.join(CONFIG_DIR, 'file_organizer_changelog.txt')

# URLs para actualizaciones
GITHUB_REPO = "https://raw.githubusercontent.com/TheKeProjects/AutoArchiver/main/version.txt"
GITHUB_CHANGELOG = "https://raw.githubusercontent.com/TheKeProjects/AutoArchiver/main/changelog.txt"
UPDATE_URL = "https://github.com/TheKeProjects/AutoArchiver/releases/latest"
INSTALLER_URL = "https://github.com/TheKeProjects/AutoArchiver/releases/latest/download/AutoArchiver_Setup.exe"

# Configuración de colores para el tema
COLORS = {
    "primary": "#6A11CB",
    "secondary": "#2575FC",
    "accent": "#FF3366",
    "background": "#2D2B3A",
    "surface": "#3A3849",
    "text": "#FFFFFF",
    "text_secondary": "#B2B2B2",
    "success": "#4CAF50",
    "warning": "#FFC107",
    "error": "#F44336"
}

VALID_EXTENSIONS_PHOTO = {'.jpg', '.jpeg', '.png', '.webp', '.gif'}
VALID_EXTENSIONS_VIDEO = {'.mp4', '.mov', '.avi'}
VALID_EXTENSIONS = VALID_EXTENSIONS_PHOTO.union(VALID_EXTENSIONS_VIDEO)

def get_windows_drives():
    drives = []
    for letter in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
        drive = f"{letter}:\\"
        if os.path.exists(drive):
            drives.append(drive)
    return drives

def natural_sort_key(s):
    return [int(text) if text.isdigit() else text.lower() for text in re.split(r'(\d+)', s)]

def escape_regexp(text):
    return re.escape(text)

def get_last_file_number(folder_path: Path, base_name: str):
    if not folder_path.exists():
        return 0
    pattern = re.compile(rf"^{escape_regexp(base_name)} (\d+)\..*$")
    max_num = 0
    for f in folder_path.iterdir():
        if f.is_file():
            m = pattern.match(f.name)
            if m:
                num = int(m.group(1))
                if num > max_num:
                    max_num = num
    return max_num

def is_hidden(filepath: Path):
    if os.name == 'nt':
        FILE_ATTRIBUTE_HIDDEN = 0x02
        FILE_ATTRIBUTE_SYSTEM = 0x04
        attrs = ctypes.windll.kernel32.GetFileAttributesW(str(filepath))
        if attrs == -1:
            return False
        return bool(attrs & (FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM))
    else:
        return filepath.name.startswith('.')

class UpdateChecker(QThread):
    update_available = pyqtSignal(str, str)  # remote_version, changelog
    no_update = pyqtSignal()
    error = pyqtSignal(str)

    def __init__(self, current_version):
        super().__init__()
        self.current_version = current_version

    def run(self):
        try:
            # Obtener versión remota
            with urllib.request.urlopen(GITHUB_REPO, timeout=5) as response:
                remote_version = response.read().decode().strip()
            
            # Comparar versiones
            if remote_version != self.current_version:
                # Descargar changelog
                try:
                    with urllib.request.urlopen(GITHUB_CHANGELOG, timeout=5) as response:
                        changelog = response.read().decode('utf-8')
                except:
                    changelog = "No se pudieron obtener las notas de la versión."
                
                self.update_available.emit(remote_version, changelog)
            else:
                self.no_update.emit()
                
        except Exception as e:
            self.error.emit(f"No se pudo verificar actualizaciones: {str(e)}")

class GradientButton(QPushButton):
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedHeight(45)
        
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Crear gradiente
        gradient = QLinearGradient(0, 0, self.width(), 0)
        gradient.setColorAt(0, QColor(COLORS["primary"]))
        gradient.setColorAt(1, QColor(COLORS["secondary"]))
        
        # Dibujar fondo con gradiente
        painter.setBrush(gradient)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRoundedRect(0, 0, self.width(), self.height(), 10, 10)
        
        # Dibujar texto
        painter.setFont(self.font())
        painter.setPen(QColor(COLORS["text"]))
        painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self.text())

class GradientFrame(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(5)
        
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Crear gradiente
        gradient = QLinearGradient(0, 0, self.width(), 0)
        gradient.setColorAt(0, QColor(COLORS["primary"]))
        gradient.setColorAt(1, QColor(COLORS["secondary"]))
        
        # Dibujar gradiente
        painter.setBrush(gradient)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRect(0, 0, self.width(), self.height())

class FolderBrowser(QWidget):
    folder_changed = pyqtSignal(Path)

    def __init__(self, title):
        super().__init__()
        self.current_path = None
        self.history = []
        
        # Configurar layout principal
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)
        self.setLayout(layout)
        
        # Título con estilo mejorado
        self.label = QLabel(title)
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label.setStyleSheet(f"""
            font-weight: bold; 
            font-size: 18px; 
            color: {COLORS["text"]};
            background: {COLORS["surface"]};
            padding: 12px;
            border-radius: 10px;
        """)
        layout.addWidget(self.label)
        
        # Layout para controles superiores
        top_controls_layout = QHBoxLayout()
        
        # Combo box para unidades
        self.drive_combo = QComboBox()
        drives = get_windows_drives()
        if drives:
            self.drive_combo.addItems(drives)
            self.drive_combo.setCurrentIndex(0)
            self.current_path = Path(drives[0])
        else:
            self.drive_combo.addItem("No hay unidades disponibles")
        self.drive_combo.currentTextChanged.connect(self.on_drive_changed)
        self.drive_combo.setStyleSheet(f"""
            QComboBox {{
                background: {COLORS["surface"]};
                border: 2px solid {COLORS["surface"]};
                border-radius: 8px;
                padding: 8px 12px;
                font-weight: 600;
                color: {COLORS["text"]};
                min-width: 110px;
            }}
            QComboBox:hover {{
                border-color: {COLORS["primary"]};
            }}
            QComboBox::drop-down {{
                border: none;
            }}
            QComboBox QAbstractItemView {{
                background: {COLORS["surface"]};
                color: {COLORS["text"]};
                selection-background-color: {COLORS["primary"]};
            }}
        """)
        top_controls_layout.addWidget(self.drive_combo)
        
        # Botón para retroceder
        self.back_button = QPushButton("◀ Atrás")
        self.back_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.back_button.clicked.connect(self.go_back)
        self.back_button.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS["surface"]};
                color: {COLORS["text"]};
                border: 2px solid {COLORS["surface"]};
                border-radius: 8px;
                padding: 8px 12px;
                font-weight: 600;
            }}
            QPushButton:hover {{
                border-color: {COLORS["primary"]};
            }}
            QPushButton:disabled {{
                color: {COLORS["text_secondary"]};
            }}
        """)
        top_controls_layout.addWidget(self.back_button)
        layout.addLayout(top_controls_layout)
        
        # Display de ruta actual
        self.path_display = QLabel("")
        self.path_display.setObjectName("path_display")
        self.path_display.setStyleSheet(f"""
            background: {COLORS["surface"]};
            color: {COLORS["text_secondary"]};
            font-family: 'Consolas', 'Courier New', monospace;
            padding: 10px;
            border-radius: 8px;
            font-size: 13px;
            margin-top: 6px;
            margin-bottom: 10px;
        """)
        layout.addWidget(self.path_display)
        
        # Lista de carpetas
        self.list_widget = QListWidget()
        self.list_widget.setStyleSheet(f"""
            QListWidget {{
                background: {COLORS["surface"]};
                border: 2px solid {COLORS["surface"]};
                border-radius: 10px;
                padding: 6px;
                font-size: 14px;
                color: {COLORS["text"]};
            }}
            QListWidget::item {{
                padding: 8px;
                border-bottom: 1px solid {COLORS["background"]};
            }}
            QListWidget::item:selected {{
                background-color: {COLORS["primary"]}40;
                color: {COLORS["text"]};
                border-radius: 6px;
            }}
            QListWidget::item:hover {{
                background-color: {COLORS["primary"]}20;
                border-radius: 6px;
            }}
        """)
        layout.addWidget(self.list_widget)
        self.list_widget.itemDoubleClicked.connect(self.on_folder_double_clicked)
        
        # Actualizar la lista de carpetas al inicializar
        if self.current_path:
            self.update_folder_list()
            self.update_back_button()

    def on_drive_changed(self, drive):
        if not drive or drive == "No hay unidades disponibles":
            return
        try:
            if self.current_path:
                self.history.clear()
            self.current_path = Path(drive)
            self.update_folder_list()
            self.folder_changed.emit(self.current_path)
            self.update_back_button()
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error al cambiar de unidad:\n{e}")

    def update_folder_list(self):
        if not self.current_path:
            self.list_widget.clear()
            self.path_display.setText("")
            return
            
        self.path_display.setText(str(self.current_path))
        self.list_widget.clear()
        try:
            folders = [f for f in self.current_path.iterdir() if f.is_dir() and not is_hidden(f)]
            folders.sort(key=lambda f: natural_sort_key(f.name))
            for folder in folders:
                self.list_widget.addItem(folder.name)
        except Exception as e:
            QMessageBox.warning(self, "Error", f"No se pudo listar carpetas:\n{e}")

    def on_folder_double_clicked(self, item):
        if not self.current_path:
            return
        new_path = self.current_path / item.text()
        if new_path.is_dir():
            self.history.append(self.current_path)
            self.current_path = new_path
            self.update_folder_list()
            self.folder_changed.emit(self.current_path)
            self.update_back_button()

    def go_back(self):
        if self.history:
            self.current_path = self.history.pop()
            self.update_folder_list()
            self.folder_changed.emit(self.current_path)
            self.update_back_button()

    def update_back_button(self):
        self.back_button.setEnabled(len(self.history) > 0)

    def get_selected_path(self):
        return self.current_path

class FolderSearchThread(QThread):
    found = pyqtSignal(str)
    finished = pyqtSignal()

    def __init__(self, root_paths, search_text):
        super().__init__()
        self.root_paths = root_paths
        self.search_text = search_text.lower()
        self._is_running = True

    def run(self):
        for root in self.root_paths:
            if not self._is_running:
                break
            for dirpath, dirnames, _ in os.walk(root):
                if not self._is_running:
                    break
                for dirname in dirnames:
                    if self.search_text in dirname.lower():
                        self.found.emit(os.path.join(dirpath, dirname))
        self.finished.emit()

    def stop(self):
        self._is_running = False

class FileOrganizerApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Organizador de Archivos")
        self.resize(1200, 800)
        self.setMinimumSize(1000, 600)
        
        # Variable para controlar el estado de selección
        self.origin_selected = False
        
        # Configuración de actualizaciones
        self.update_available = False
        self.current_version = self.get_current_version()
        
        # Crear carpeta de configuración si no existe
        os.makedirs(CONFIG_DIR, exist_ok=True)
        
        # Configurar paleta de colores
        self.apply_dark_palette()
        
        # Layout principal
        self.main_layout = QVBoxLayout()
        self.main_layout.setContentsMargins(20, 20, 20, 20)
        self.main_layout.setSpacing(15)
        self.setLayout(self.main_layout)
        
        # Título principal
        title_label = QLabel("Organizador de Archivos Multimedia")
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label.setStyleSheet(f"""
            font-size: 24px;
            font-weight: bold;
            color: {COLORS["text"]};
            padding: 15px;
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                                        stop:0 {COLORS["primary"]}, 
                                        stop:1 {COLORS["secondary"]});
            border-radius: 15px;
        """)
        self.main_layout.addWidget(title_label)
        
        # Línea decorativa con gradiente
        gradient_line = GradientFrame()
        self.main_layout.addWidget(gradient_line)
        
        # Layout para los paneles de navegación
        self.browsers_layout = QHBoxLayout()
        self.browsers_layout.setSpacing(20)
        self.main_layout.addLayout(self.browsers_layout)
        
        # Panel origen
        self.source_browser = FolderBrowser("📁 CARPETA DE ORIGEN")
        self.source_browser.folder_changed.connect(self.on_origin_folder_changed)
        self.browsers_layout.addWidget(self.source_browser)
        
        # Panel destino (oculto al inicio)
        self.dest_browser = FolderBrowser("📂 CARPETA DE DESTINO")
        self.dest_browser.folder_changed.connect(self.on_dest_folder_changed)
        self.dest_browser.hide()
        self.browsers_layout.addWidget(self.dest_browser)
        
        # Overlay para panel origen
        self.overlay = QWidget(self.source_browser)
        self.overlay.setStyleSheet("background-color: rgba(45, 43, 58, 0.85); border-radius: 10px;")
        self.overlay.hide()
        
        # Botón volver a origen
        self.back_to_origin_button = GradientButton("⬅️ Volver al Origen")
        self.back_to_origin_button.setParent(self.overlay)
        self.back_to_origin_button.clicked.connect(self.show_origin_only)
        self.back_to_origin_button.hide()
        
        # Botón siguiente
        self.next_button = GradientButton("Siguiente ➡️")
        self.next_button.setEnabled(False)
        self.next_button.clicked.connect(self.show_dest_browser)
        self.main_layout.addWidget(self.next_button)
        
        # Botón transferir archivos
        self.transfer_button = GradientButton("🔄 Transferir Archivos")
        self.transfer_button.clicked.connect(self.transfer_files)
        self.transfer_button.hide()
        self.main_layout.addWidget(self.transfer_button)
        
        # Barra superior con botones de control
        top_buttons_layout = QHBoxLayout()
        top_buttons_layout.addStretch()
        
        # Botón de actualizaciones
        self.update_button = QPushButton("🔄 Actualizar")
        self.update_button.setToolTip("Buscar actualizaciones disponibles")
        self.update_button.setFixedSize(120, 40)
        self.update_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.update_button.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS["surface"]};
                color: {COLORS["text"]};
                border: 2px solid {COLORS["surface"]};
                border-radius: 8px;
                padding: 8px;
                font-weight: 600;
            }}
            QPushButton:hover {{
                border-color: {COLORS["primary"]};
            }}
        """)
        self.update_button.clicked.connect(self.check_updates_ui)
        top_buttons_layout.addWidget(self.update_button)
        
        # Botón info
        self.info_button = QPushButton("ℹ️ Info")
        self.info_button.setToolTip("Más información sobre cómo funciona el programa")
        self.info_button.setFixedSize(100, 40)
        self.info_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.info_button.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS["surface"]};
                color: {COLORS["text"]};
                border: 2px solid {COLORS["surface"]};
                border-radius: 8px;
                padding: 8px;
                font-weight: 600;
            }}
            QPushButton:hover {{
                border-color: {COLORS["primary"]};
            }}
        """)
        self.info_button.clicked.connect(self.show_info_dialog)
        top_buttons_layout.addWidget(self.info_button)
        
        self.main_layout.insertLayout(0, top_buttons_layout)
        
        # Barra de estado
        self.status_label = QLabel("Selecciona una carpeta de origen para comenzar")
        self.status_label.setStyleSheet(f"""
            color: {COLORS["text_secondary"]}; 
            font-size: 14px; 
            padding: 10px;
            background: {COLORS["surface"]};
            border-radius: 10px;
        """)
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.main_layout.addWidget(self.status_label)
        
        # Buscador de carpetas
        search_layout = QHBoxLayout()
        self.main_layout.addLayout(search_layout)
        
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("🔍 Buscar carpeta por nombre...")
        self.search_input.setStyleSheet(f"""
            QLineEdit {{
                font-size: 14px;
                font-weight: 500;
                padding: 12px 16px;
                border: 2px solid {COLORS["surface"]};
                border-radius: 12px;
                background: {COLORS["surface"]};
                color: {COLORS["text"]};
            }}
            QLineEdit:focus {{
                border-color: {COLORS["primary"]};
            }}
        """)
        search_layout.addWidget(self.search_input)
        
        self.search_button = QPushButton("Buscar")
        self.search_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.search_button.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS["surface"]};
                color: {COLORS["text"]};
                border: 2px solid {COLORS["surface"]};
                border-radius: 12px;
                padding: 12px 20px;
                font-weight: 600;
            }}
            QPushButton:hover {{
                border-color: {COLORS["primary"]};
            }}
        """)
        search_layout.addWidget(self.search_button)
        
        self.search_results = QListWidget()
        self.search_results.setMaximumHeight(0)
        self.search_results.setVisible(False)
        self.search_results.setStyleSheet(f"""
            QListWidget {{
                background: {COLORS["surface"]};
                border: 2px solid {COLORS["surface"]};
                border-radius: 10px;
                padding: 6px;
                font-size: 14px;
                color: {COLORS["text"]};
            }}
            QListWidget::item:selected {{
                background-color: {COLORS["primary"]}40;
                color: {COLORS["text"]};
                border-radius: 6px;
            }}
            QListWidget::item:hover {{
                background-color: {COLORS["primary"]}20;
                border-radius: 6px;
            }}
        """)
        self.main_layout.addWidget(self.search_results)
        self.search_results.itemDoubleClicked.connect(self.on_search_result_double_clicked)
        
        # Barra de progreso
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setFixedHeight(20)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setStyleSheet(f"""
            QProgressBar {{
                border: 2px solid {COLORS["surface"]};
                border-radius: 10px;
                background: {COLORS["surface"]};
                color: {COLORS["text"]};
                font-weight: 600;
                font-size: 12px;
                text-align: center;
            }}
            QProgressBar::chunk {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                                           stop:0 {COLORS["primary"]}, 
                                           stop:1 {COLORS["secondary"]});
                border-radius: 10px;
            }}
        """)
        self.main_layout.addWidget(self.progress_bar)
        
        # Configurar búsqueda
        self.search_thread = None
        self.search_timer = QTimer()
        self.search_timer.setSingleShot(True)
        self.search_timer.timeout.connect(self.perform_search)
        self.search_input.textChanged.connect(self.on_search_text_changed)
        self.search_button.clicked.connect(self.perform_search)
        
        # Ajustar overlay
        self.resizeEvent(None)
        
        # Verificar actualizaciones en segundo plano al iniciar
        self.check_for_updates_in_background()
        
        # Mostrar cambios si es una nueva instalación
        self.show_update_changes_if_needed()

    def get_current_version(self):
        """Obtiene la versión actual de la aplicación"""
        try:
            if os.path.exists(VERSION_FILE):
                with open(VERSION_FILE, "r") as f:
                    return f.read().strip()
        except:
            pass
        return "1.3.1"  # Versión inicial

    def save_current_version(self, version):
        """Guarda la versión actual en un archivo"""
        try:
            with open(VERSION_FILE, "w") as f:
                f.write(version)
        except:
            pass

    def check_for_updates_in_background(self):
        """Verifica actualizaciones en segundo plano"""
        self.update_checker = UpdateChecker(self.current_version)
        self.update_checker.update_available.connect(self.on_update_available)
        self.update_checker.no_update.connect(self.on_no_update)
        self.update_checker.error.connect(self.on_update_error)
        self.update_checker.start()

    def check_updates_ui(self):
        """Verifica actualizaciones desde la interfaz de usuario"""
        self.update_button.setEnabled(False)
        self.update_button.setText("Buscando...")
        self.status_label.setText("Buscando actualizaciones...")
        
        self.update_checker = UpdateChecker(self.current_version)
        self.update_checker.update_available.connect(self.on_update_available)
        self.update_checker.no_update.connect(self.on_no_update)
        self.update_checker.error.connect(self.on_update_error)
        self.update_checker.finished.connect(lambda: self.update_button.setEnabled(True))
        self.update_checker.start()

    def on_update_available(self, remote_version, changelog):
        """Maneja la disponibilidad de una actualización"""
        self.update_available = True
        self.update_button.setText("¡Actualizar!")
        self.update_button.setStyleSheet(f"""
            QPushButton {{
                background: {COLORS["success"]};
                color: {COLORS["text"]};
                border: 2px solid {COLORS["success"]};
                border-radius: 8px;
                padding: 8px;
                font-weight: 600;
            }}
            QPushButton:hover {{
                border-color: {COLORS["primary"]};
            }}
        """)
        
        message = f"¡Hay una nueva versión disponible!\n\n" \
                  f"Versión actual: {self.current_version}\n" \
                  f"Nueva versión: {remote_version}\n\n" \
                  f"Notas de la versión:\n{changelog}\n\n" \
                  "¿Deseas actualizar ahora?"
        
        reply = QMessageBox.question(self, "Actualización disponible", message, 
                                   QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        
        if reply == QMessageBox.StandardButton.Yes:
            self.perform_update(remote_version, changelog)

    def on_no_update(self):
        """Maneja cuando no hay actualizaciones disponibles"""
        self.update_available = False
        self.update_button.setText("Actualizar")
        self.status_label.setText("Ya tienes la última versión.")
        QMessageBox.information(self, "Actualización", "Ya tienes la última versión.")

    def on_update_error(self, error_msg):
        """Maneja errores en la verificación de actualizaciones"""
        self.update_available = False
        self.update_button.setText("Actualizar")
        self.status_label.setText("Error al verificar actualizaciones")
        QMessageBox.warning(self, "Error", error_msg)

    def perform_update(self, remote_version, changelog):
        """Realiza el proceso de actualización"""
        try:
            # Guardar changelog para mostrar después de la actualización
            with open(CHANGELOG_FILE, "w", encoding="utf-8") as f:
                f.write(remote_version + "\n\n" + changelog)
                
            if sys.platform == "win32":
                try:
                    temp_dir = tempfile.gettempdir()
                    installer_path = os.path.join(temp_dir, "File_Organizer_Updater.exe")
                    
                    # Descargar el instalador
                    self.status_label.setText("Descargando actualización...")
                    with urllib.request.urlopen(INSTALLER_URL) as response:
                        with open(installer_path, 'wb') as out_file:
                            out_file.write(response.read())
                    
                    # Ejecutar el instalador
                    subprocess.Popen([installer_path, "/SILENT"])
                    self.close_app()
                except Exception as e:
                    QMessageBox.critical(self, "Error de actualización", 
                                        f"No se pudo descargar el actualizador: {str(e)}\n"
                                        "Por favor, actualiza manualmente desde GitHub.")
                    webbrowser.open(UPDATE_URL)
            else:
                webbrowser.open(UPDATE_URL)
                QMessageBox.information(self, "Actualización manual", 
                                       "Por favor, descarga la última versión desde el navegador.")
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error durante la actualización: {str(e)}")

    def show_update_changes_if_needed(self):
        """Muestra los cambios si se acaba de actualizar"""
        if os.path.exists(CHANGELOG_FILE):
            try:
                with open(CHANGELOG_FILE, "r", encoding="utf-8") as f:
                    content = f.read()
                    parts = content.split("\n\n", 1)
                    version = parts[0]
                    changelog = parts[1] if len(parts) > 1 else "No hay notas disponibles."
                
                QMessageBox.information(self, f"Notas de la versión {version}", changelog)
                os.remove(CHANGELOG_FILE)
                
                # Actualizar la versión actual
                self.current_version = version
                self.save_current_version(version)
                
            except Exception as e:
                print(f"Error al mostrar cambios de actualización: {e}")

    def close_app(self):
        """Cierra la aplicación"""
        QApplication.quit()

    def apply_dark_palette(self):
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(COLORS["background"]))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(COLORS["text"]))
        palette.setColor(QPalette.ColorRole.Base, QColor(COLORS["surface"]))
        palette.setColor(QPalette.ColorRole.AlternateBase, QColor(COLORS["surface"]))
        palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(COLORS["surface"]))
        palette.setColor(QPalette.ColorRole.ToolTipText, QColor(COLORS["text"]))
        palette.setColor(QPalette.ColorRole.Text, QColor(COLORS["text"]))
        palette.setColor(QPalette.ColorRole.Button, QColor(COLORS["surface"]))
        palette.setColor(QPalette.ColorRole.ButtonText, QColor(COLORS["text"]))
        palette.setColor(QPalette.ColorRole.BrightText, QColor(COLORS["accent"]))
        palette.setColor(QPalette.ColorRole.Highlight, QColor(COLORS["primary"]))
        palette.setColor(QPalette.ColorRole.HighlightedText, QColor(COLORS["text"]))
        QApplication.instance().setPalette(palette)

    def show_info_dialog(self):
        info_text = (
            "Este programa permite organizar archivos de fotos y videos desde una carpeta de origen "
            "a una carpeta de destino.\n\n"
            "1. Selecciona la unidad y carpeta de origen donde están tus archivos.\n"
            "2. Haz clic en 'Siguiente' para seleccionar la carpeta destino.\n"
            "3. En la carpeta destino, los archivos se copiarán en subcarpetas 'Fotos' o 'Videos' según su tipo.\n"
            "4. Los archivos se renombrarán automáticamente con el nombre de la carpeta destino seguido de un número.\n"
            "5. Puedes buscar carpetas rápidamente usando el buscador.\n\n"
            "Solo se copian archivos con extensiones válidas de fotos y videos.\n"
            "Las imágenes se convierten a JPEG excepto los GIFs, que se copian tal cual.\n\n"
            f"Versión actual: {self.current_version}\n\n"
            "Presiona 'Transferir Archivos' para iniciar la copia."
        )
        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Icon.Information)
        msg.setWindowTitle("Información del Organizador")
        msg.setText(info_text)
        msg.setStyleSheet(f"""
            QMessageBox {{
                background: {COLORS["background"]};
                color: {COLORS["text"]};
            }}
            QMessageBox QLabel {{
                color: {COLORS["text"]};
            }}
        """)
        msg.exec()

    def resizeEvent(self, event):
        self.overlay.setGeometry(self.source_browser.rect())
        btn_w = self.back_to_origin_button.sizeHint().width()
        btn_h = self.back_to_origin_button.sizeHint().height()
        ow = self.overlay.width()
        oh = self.overlay.height()
        self.back_to_origin_button.move(max(0, (ow - btn_w) // 2 - 275), (oh - btn_h) // 2)
        super().resizeEvent(event)

    def on_origin_folder_changed(self, path):
        self.next_button.setEnabled(path is not None)
        if path:
            self.status_label.setText(f"Origen seleccionado: {path}")

    def show_dest_browser(self):
        self.origin_selected = True
        self.dest_browser.show()
        self.transfer_button.show()
        self.next_button.hide()
        self.overlay.show()
        self.overlay.raise_()
        self.back_to_origin_button.show()
        self.back_to_origin_button.raise_()
        self.status_label.setText("Selecciona una carpeta de destino")

    def show_origin_only(self):
        self.origin_selected = False
        self.dest_browser.hide()
        self.transfer_button.hide()
        self.next_button.show()
        self.back_to_origin_button.hide()
        self.overlay.hide()
        self.status_label.setText("Selecciona una carpeta de origen")

    def on_dest_folder_changed(self, path):
        if path:
            self.status_label.setText(f"Destino seleccionado: {path}")

    def on_search_text_changed(self, text):
        if self.search_thread:
            self.search_thread.stop()
            self.search_thread.wait()
            self.search_thread = None
        if not text.strip():
            self.search_results.clear()
            self.search_results.setVisible(False)
            self.search_results.setMaximumHeight(0)
            self.progress_bar.setVisible(False)
            return
        self.search_timer.start(300)

    def perform_search(self):
        text = self.search_input.text().strip()
        self.search_results.clear()
        if self.search_thread:
            self.search_thread.stop()
            self.search_thread.wait()
            self.search_thread = None
        if not text:
            self.progress_bar.setVisible(False)
            self.search_results.setVisible(False)
            self.search_results.setMaximumHeight(0)
            return
        roots = get_windows_drives()
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)
        self.search_results.setVisible(True)
        self.search_results.setMaximumHeight(150)
        self.search_thread = FolderSearchThread(roots, text)
        self.search_thread.found.connect(self.add_search_result)
        self.search_thread.finished.connect(self.search_finished)
        self.search_thread.start()

    def add_search_result(self, path):
        self.search_results.addItem(path)

    def search_finished(self):
        self.progress_bar.setVisible(False)
        if self.search_results.count() == 0:
            self.search_results.addItem("No se encontraron carpetas con ese nombre.")

    def on_search_result_double_clicked(self, item):
        path = Path(item.text())
        if path.is_dir():
            drive = str(path.drive)
            if self.origin_selected:
                # Si estamos en modo selección de destino
                if drive == self.dest_browser.drive_combo.currentText():
                    self.dest_browser.current_path = path
                    self.dest_browser.update_folder_list()
                else:
                    self.dest_browser.drive_combo.setCurrentText(drive)
                    self.dest_browser.current_path = path
                    self.dest_browser.update_folder_list()
            else:
                # Si estamos en modo selección de origen
                if drive == self.source_browser.drive_combo.currentText():
                    self.source_browser.current_path = path
                    self.source_browser.update_folder_list()
                else:
                    self.source_browser.drive_combo.setCurrentText(drive)
                    self.source_browser.current_path = path
                    self.source_browser.update_folder_list()
                self.next_button.setEnabled(True)
            
            # Limpiar resultados de búsqueda
            self.search_results.clear()
            self.search_results.setVisible(False)
            self.search_results.setMaximumHeight(0)
            self.search_input.clear()

    def transfer_files(self):
        origin = self.source_browser.get_selected_path()
        destination = self.dest_browser.get_selected_path()
        if not origin or not destination:
            QMessageBox.warning(self, "Error", "¡Selecciona origen y destino primero!")
            return
        
        # Configurar y mostrar barra de progreso
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        
        try:
            # Simular progreso (en una aplicación real, esto se conectaría al proceso real)
            for i in range(101):
                self.progress_bar.setValue(i)
                QApplication.processEvents()
                QThread.msleep(20)  # Simular trabajo
            
            copied_files, total_files = self.process_files(origin, destination)
            
            # Mostrar mensaje de éxito
            success_msg = QMessageBox(self)
            success_msg.setIcon(QMessageBox.Icon.Information)
            success_msg.setWindowTitle("Transferencia completada")
            success_msg.setText(f"✅ Copiados {copied_files}/{total_files} archivos")
            success_msg.setStyleSheet(f"""
                QMessageBox {{
                    background: {COLORS["background"]};
                    color: {COLORS["text"]};
                }}
                QMessageBox QLabel {{
                    color: {COLORS["text"]};
                }}
            """)
            success_msg.exec()
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"❌ Error en la transferencia:\n{e}")
        finally:
            self.progress_bar.setVisible(False)

    def process_files(self, origin: Path, destination: Path):
        all_entries = list(origin.iterdir())
        files = [f for f in all_entries if f.is_file() and f.suffix.lower() in VALID_EXTENSIONS]
        files.sort(key=lambda f: natural_sort_key(f.name))
        base_name = destination.name
        processed_files = 0
        for file_path in files:
            ext = file_path.suffix.lower()
            is_photo = ext in VALID_EXTENSIONS_PHOTO
            is_video = ext in VALID_EXTENSIONS_VIDEO
            if not (is_photo or is_video):
                continue
            target_folder = destination / ('Fotos' if is_photo else 'Videos')
            if not target_folder.exists():
                target_folder.mkdir(parents=True, exist_ok=True)
            last_number = get_last_file_number(target_folder, base_name)
            new_number = last_number + 1
            new_ext = ext if (is_photo and ext == '.gif') or is_video else '.jpg'
            new_name = f"{base_name} {new_number}{new_ext}"
            new_path = target_folder / new_name
            try:
                if is_photo and ext != '.gif':
                    with Image.open(file_path) as img:
                        rgb_img = img.convert('RGB')
                        rgb_img.save(new_path, 'JPEG', quality=100)
                else:
                    shutil.copy2(file_path, new_path)
                processed_files += 1
            except Exception as e:
                print(f"Error copiando {file_path.name}: {e}")
        return processed_files, len(files)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.source_browser.go_back()
            self.dest_browser.go_back()
        else:
            super().keyPressEvent(event)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # Establecer estilo de la aplicación
    app.setStyle("Fusion")
    
    window = FileOrganizerApp()
    window.show()
    sys.exit(app.exec())